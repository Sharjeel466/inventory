			</div>
		</div>
	</div>
</div>
</div>

<?php 
include('footer.php');
?>